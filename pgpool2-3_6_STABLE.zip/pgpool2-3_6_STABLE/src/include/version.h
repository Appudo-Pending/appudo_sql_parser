#define PGPOOLVERSION "subaruboshi"
