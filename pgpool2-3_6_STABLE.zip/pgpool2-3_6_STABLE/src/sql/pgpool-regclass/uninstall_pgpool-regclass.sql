DROP FUNCTION pgpool_regclass(cstring);
