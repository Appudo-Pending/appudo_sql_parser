export CLASSPATH=.:$JDBC_DRIVER
javac Main.java
java Main
