#ifndef POOL_H
#define POOL_H

#include <stdio.h>
#include <string.h>

#define pool_error printf
#define child_exit exit

#endif

